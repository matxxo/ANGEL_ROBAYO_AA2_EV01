import java.sql.*;  // Importar las bibliotecas SQL necesarias
import java.util.logging.Level;
import java.util.logging.Logger;

public class App {
    public static void main(String[] args) {
        // Configuración de la conexión a la base de datos
        String usuario = "root";  // Usuario de la base de datos
        String password = "";  // Contraseña del usuario
        String url = "jdbc:mysql://localhost:3306/db_reposteria";  // URL de conexión a la base de datos
        
        // Declaración de objetos para la conexión
        Connection c;  // Objeto de conexión
        Statement statement;  // Objeto para ejecutar sentencias SQL
        ResultSet rs;  // Objeto para almacenar el resultado de las consultas SQL

        // Cargar el driver de MySQL
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // Carga del controlador JDBC
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);  // Manejo de la excepción si no se encuentra el driver
        }

        // Establecer conexión y realizar operaciones en la base de datos
        try {
            c = DriverManager.getConnection(url, usuario, password);  // Conexión a la base de datos
            statement = c.createStatement();  // Crear objeto Statement para ejecutar consultas

            // Insertar un nuevo registro en la tabla empleados
            statement.executeUpdate("INSERT INTO empleados(nombre, cargo, contraseña) VALUES('Luna Martínez', 'vendedor', 'Meow9')");
            
            // Ejecutar una consulta SQL para obtener todos los registros de la tabla empleados
            rs = statement.executeQuery("SELECT * FROM empleados");
            rs.next();  // Mover el cursor al primer registro
            
            // Recorrer y mostrar los resultados de la consulta
            do {
                System.out.println(rs.getInt("id_empleado") + ": " + rs.getString("nombre"));  // Imprimir ID y nombre del empleado
            } while (rs.next());  // Continuar recorriendo mientras haya más registros
        } catch (SQLException ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);  // Manejo de la excepción si ocurre un error SQL
        }
    }
}
