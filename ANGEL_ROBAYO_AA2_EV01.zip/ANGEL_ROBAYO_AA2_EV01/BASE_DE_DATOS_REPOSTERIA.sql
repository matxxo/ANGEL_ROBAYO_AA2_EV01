SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema DB_reposteria
-- -----------------------------------------------------

CREATE SCHEMA IF NOT EXISTS `DB_reposteria` DEFAULT CHARACTER SET utf8;
USE `DB_reposteria`;

-- -----------------------------------------------------
-- Table `DB_reposteria`.`empleados`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DB_reposteria`.`empleados` (
  `id_empleado` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(70) NOT NULL,
  `cargo` VARCHAR(45) NOT NULL,
  `contraseña` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_empleado`)
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `DB_reposteria`.`producto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DB_reposteria`.`producto` (
  `id_producto` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre_pdto` VARCHAR(45) NOT NULL,
  `precio_und` FLOAT UNSIGNED NOT NULL,
  `descripcion` VARCHAR(250) NOT NULL,
  `fecha_caduc` DATETIME(6) NOT NULL,
  PRIMARY KEY (`id_producto`)
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `DB_reposteria`.`producto_sumins`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DB_reposteria`.`producto_sumins` (
  `id_producto_sum` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre_pdto` VARCHAR(45) NOT NULL,
  `precio_und` FLOAT UNSIGNED NOT NULL,
  `descripcion` VARCHAR(250) NOT NULL,
  `fecha_caduc` DATETIME(6) NOT NULL,
  PRIMARY KEY (`id_producto_sum`)
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `DB_reposteria`.`venta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DB_reposteria`.`venta` (
  `id_pedidos` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fecha` DATETIME(6) NOT NULL,
  `total_a_pagar` DECIMAL(10, 2) UNSIGNED NOT NULL,
  `producto_id_producto` INT UNSIGNED NOT NULL,
  `empleados_id_empleado` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id_pedidos`),
  INDEX `fk_venta_producto_idx` (`producto_id_producto`),
  INDEX `fk_venta_empleados1_idx` (`empleados_id_empleado`),
  CONSTRAINT `fk_venta_producto`
    FOREIGN KEY (`producto_id_producto`)
    REFERENCES `DB_reposteria`.`producto` (`id_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_venta_empleados1`
    FOREIGN KEY (`empleados_id_empleado`)
    REFERENCES `DB_reposteria`.`empleados` (`id_empleado`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `DB_reposteria`.`inventario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DB_reposteria`.`inventario` (
  `id_inventario` INT NOT NULL AUTO_INCREMENT,
  `stock_productos` INT UNSIGNED NOT NULL,
  `stock_productos_sum` INT UNSIGNED NOT NULL,
  `producto_id_producto` INT UNSIGNED NOT NULL,
  `producto_sumins_id_producto_sum` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id_inventario`),
  INDEX `fk_inventario_producto1` (`producto_id_producto`),
  INDEX `fk_inventario_producto_sumins1` (`producto_sumins_id_producto_sum`),
  CONSTRAINT `fk_inventario_producto1`
    FOREIGN KEY (`producto_id_producto`)
    REFERENCES `DB_reposteria`.`producto` (`id_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_inventario_producto_sumins1`
    FOREIGN KEY (`producto_sumins_id_producto_sum`)
    REFERENCES `DB_reposteria`.`producto_sumins` (`id_producto_sum`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `DB_reposteria`.`proveedor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DB_reposteria`.`proveedor` (
  `id_proveedor` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NULL DEFAULT NULL,
  `telefono` INT UNSIGNED NOT NULL,
  `correo` VARCHAR(45) NOT NULL,
  `ubicacion` VARCHAR(45) NOT NULL,
  `producto_sumins_id_producto_sum` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id_proveedor`),
  INDEX `fk_proveedor_producto_sumins1_idx` (`producto_sumins_id_producto_sum`),
  CONSTRAINT `fk_proveedor_producto_sumins1`
    FOREIGN KEY (`producto_sumins_id_producto_sum`)
    REFERENCES `DB_reposteria`.`producto_sumins` (`id_producto_sum`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB;

-- Restaurar los valores originales
SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
